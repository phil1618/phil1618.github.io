Dim yearCount As Integer
Dim rents() As Double
Dim maintenances() As Double
Dim managements() As Double
Dim rentalLosses() As Double
Dim rentalCosts() As Double
Dim fireInsurances() As Double
Dim deathInsurances() As Double
Dim withholdings() As Double
Dim withholdingIPPs() As Double
Dim taxes() As Double
Dim taxBases() As Double
Dim loanClassicMonthlyCharge As Double
Dim loanClassicRefunds() As Double
Dim loanClassicInterests() As Double
Dim loanBulletMonthlyCharge As Double
Dim loanBulletRefunds() As Double
Dim loanBulletInterests() As Double
Dim outcomes() As Double
Dim incomes() As Double
Dim cashflows() As Double
Dim incomeMiscellaneous() As Double
Dim buildingValues() As Double
Dim cumulatedCashflows() As Double
Dim remainingClassicRefunds() As Double
Dim remainingBulletRefunds() As Double
Dim remainingRefunds() As Double
Dim remainingBalances() As Double
Dim initialContributions() As Double
Dim netBalances() As Double
Dim inflationFactors() As Double
Dim healthIndexes() As Double
Dim realestateIndexes() As Double

Function rentByYear(yCount As Integer) As Double()
    Dim rentByYearTmp() As Double
    ReDim Preserve rentByYearTmp(0 To yCount)
    
    initialMonthlyRent = Worksheets("Paramètres").Range("MonthlyRentalValue")
    emptyRentDurationInMonth = Worksheets("Paramètres").Range("EmptyRentalMonthCount")
    
    For i = 0 To yCount - 1
        Dim remainingRentDurationInMonth As Integer
        If emptyRentDurationInMonth - (i * 12) >= 0 Then
            remainingRentDurationInMonth = emptyRentDurationInMonth - (i * 12)
        Else
            remainingRentDurationInMonth = 0
        End If

        Dim currentYearEmptyRentDurationInMonth As Integer
        If remainingRentDurationInMonth >= 12 Then
            currentYearEmptyRentDurationInMonth = 12
        Else
            currentYearEmptyRentDurationInMonth = remainingRentDurationInMonth
        End If

        v = (12 - currentYearEmptyRentDurationInMonth) * initialMonthlyRent
        
        rentByYearTmp(i) = v * (1 + healthIndexes(i)) ^ (i)
    Next
    
    rentByYear = rentByYearTmp
    
End Function

Function maintenanceByYear(yCount As Integer) As Double()
    Dim maintenanceByYearTmp() As Double
    ReDim Preserve maintenanceByYearTmp(0 To yCount)
    
    firstPhaseRentFactor = Sheets("Paramètres").Range("MaintenanceCostsPhase1").Value
    secondPhaseRentFactor = Sheets("Paramètres").Range("MaintenanceCostsPhase2").Value
    firstPhaseDurationInYear = Sheets("Paramètres").Range("MaintenanceDurationPhase1").Value
    
    For i = 0 To yearCount - 1
        rentFactor = IIf(i + 1 <= firstPhaseDurationInYear, firstPhaseRentFactor, secondPhaseRentFactor)
        maintenanceByYearTmp(i) = rents(i) * rentFactor
    Next
    
    maintenanceByYear = maintenanceByYearTmp
End Function

Function managementByYear(yCount As Integer) As Double()
    Dim managementByYearTmp() As Double
    ReDim Preserve managementByYearTmp(0 To yCount)
    
    rentFactor = Sheets("Paramètres").Range("RentalManagement").Value
    
    For i = 0 To yearCount - 1
        managementByYearTmp(i) = rents(i) * rentFactor
    Next
    
    managementByYear = managementByYearTmp
End Function

Function rentalLossByYear(yCount As Integer) As Double()
    Dim rentalLossByYearTmp() As Double
    ReDim Preserve rentalLossByYearTmp(0 To yCount)
    
    rentalLossFactor = Sheets("Paramètres").Range("RentalLossAnnualPercentageRate").Value
    
    For i = 0 To yearCount - 1
        rentalLossByYearTmp(i) = rents(i) * rentalLossFactor
    Next
    
    rentalLossByYear = rentalLossByYearTmp
End Function

Function rentalCostByYear(yCount As Integer) As Double()
    Dim rentalCostByYearTmp() As Double
    ReDim Preserve rentalCostByYearTmp(0 To yCount)
    
    rentalCostFactor = 0.21
    rentalCostStatus = Sheets("Paramètres").Range("RentingOutFees").Value

    For i = 0 To yearCount - 1
        If i Mod 3 = 0 And rentalCostStatus = "Oui" Then
            rentalCostByYearTmp(i) = (rents(i) / 12) * (1 + rentalCostFactor)
        Else
            rentalCostByYearTmp(i) = 0
        End If
    Next
    
    rentalCostByYear = rentalCostByYearTmp
End Function

Function fireInsuranceByYear(yCount As Integer) As Double()
    Dim fireInsuranceByYearTmp() As Double
    ReDim Preserve fireInsuranceByYearTmp(0 To yCount)
    
    initialValue = Sheets("Paramètres").Range("FireInsuranceAnnualCost").Value
    
    For i = 0 To yearCount - 1
        fireInsuranceByYearTmp(i) = initialValue * (1 + inflationFactors(i)) ^ (i)
    Next
    
    fireInsuranceByYear = fireInsuranceByYearTmp
End Function

Function deathInsuranceByYear(yCount As Integer) As Double()
    Dim deathInsuranceByYearTmp() As Double
    ReDim Preserve deathInsuranceByYearTmp(0 To yCount)
    
    initialValue = Sheets("Paramètres").Range("DeathInsuranceAnnualCost").Value
    durationInYear = Sheets("Paramètres").Range("DeathInsuranceDuration").Value
    
    For i = 0 To yearCount - 1
        normalizationFactor = IIf(i + 1 <= durationInYear, 1, 0)
        deathInsuranceByYearTmp(i) = initialValue * normalizationFactor * (1 + inflationFactors(i)) ^ (i)
    Next
    
    deathInsuranceByYear = deathInsuranceByYearTmp
End Function

Function withholdingsByYear(yCount As Integer) As Double()
    ' Set index value
    defaultIndex = Sheets("Variables").Range("D2").Value
    Sheets("Paramètres").Range("G23").Value = defaultIndex
    
    ' Set rate
    region = Sheets("Paramètres").Range("City").Value
    If region = "Bruxelles" Then
        Sheets("Paramètres").Range("G24").Value = Sheets("Variables").Range("E2").Value
    ElseIf region = "Flandre" Then
        Sheets("Paramètres").Range("G24").Value = Sheets("Variables").Range("E3").Value
    Else
        Sheets("Paramètres").Range("G24").Value = Sheets("Variables").Range("E4").Value
    End If
    
    ' Set communal tax
    If IsEmpty(Sheets("Paramètres").Range("G25").Value) Then
        Sheets("Paramètres").Range("G25").Value = Sheets("Variables").Range("F2").Value
    End If
    
    ' Set provincial tax
    If IsEmpty(Sheets("Paramètres").Range("G26").Value) Then
        Sheets("Paramètres").Range("G26").Value = Sheets("Variables").Range("G2").Value
    End If
    
    ' Set revenu cadastral
    If IsEmpty(Sheets("Paramètres").Range("CadastralIncome").Value) Then
        Sheets("Paramètres").Range("CadastralIncome").Value = Sheets("Variables").Range("H2").Value
    End If
    
    revenuValue = Sheets("Paramètres").Range("CadastralIncome").Value
    indexValue = Sheets("Paramètres").Range("G23").Value
    rateValue = Sheets("Paramètres").Range("G24").Value
    tax1Value = Sheets("Paramètres").Range("G25").Value
    tax2Value = Sheets("Paramètres").Range("G26").Value
    
    If IsEmpty(Sheets("Paramètres").Range("G27").Value) Then
        initialWithholdings = (revenuValue * indexValue) * rateValue
        Sheets("Paramètres").Range("G27").Value = initialWithholdings * (1 + (tax1Value / 100) + (tax2Value / 100))
    End If
    
    Dim withholdingsByYearTmp() As Double
    ReDim Preserve withholdingsByYearTmp(0 To yCount)
    
    initialValue = Sheets("Paramètres").Range("G27").Value
    
    For i = 0 To yearCount - 1
        withholdingsByYearTmp(i) = initialValue * (1 + inflationFactors(i)) ^ (i)
    Next
    
    withholdingsByYear = withholdingsByYearTmp
End Function

Function withholdingsIPPByYear(yCount As Integer) As Double()
    Dim withholdingsIPPByYearTmp() As Double
    ReDim Preserve withholdingsIPPByYearTmp(0 To yCount)
    
    revenuValue = Sheets("Paramètres").Range("CadastralIncome").Value
    indexValue = Sheets("Paramètres").Range("G23").Value
    increaseFactor = Sheets("Variables").Range("I2").Value
    
    initialValue = (revenuValue * indexValue) * increaseFactor
    
    For i = 0 To yearCount - 1
        withholdingsIPPByYearTmp(i) = initialValue * (1 + inflationFactors(i)) ^ (i)
    Next
    
    withholdingsIPPByYear = withholdingsIPPByYearTmp
End Function

Function taxesByYear(yCount As Integer) As Double()
    Dim taxesByYearTmp() As Double
    ReDim Preserve taxesByYearTmp(0 To yCount)
    
    For i = 0 To yearCount - 1
        taxesByYearTmp(i) = 0 * (1 + inflationFactors(i)) ^ (i)
    Next
    
    taxesByYear = taxesByYearTmp
End Function

Function taxBasesByYear(yCount As Integer) As Double()
    Dim taxBasesByYearTmp() As Double
    ReDim Preserve taxBasesByYearTmp(0 To yCount)
    
    For i = 0 To yearCount - 1
        taxBasesByYearTmp(i) = 0 * (1 + inflationFactors(i)) ^ (i)
    Next
    
    taxBasesByYear = taxBasesByYearTmp
End Function

Function incomeMiscellaneousByYear(yCount As Integer) As Double()
    Dim incomeMiscellaneousTmp() As Double
    ReDim Preserve incomeMiscellaneousTmp(0 To yCount)
    
    For i = 0 To yearCount - 1
        incomeMiscellaneousTmp(i) = 0 * (1 + inflationFactors(i)) ^ (i)
    Next
    
    incomeMiscellaneousByYear = incomeMiscellaneous
End Function

Function buildingValuesByYear(yCount As Integer) As Double()
    Dim buildingValuesTmp() As Double
    ReDim Preserve buildingValuesTmp(0 To yCount)
    
    initialValue = Sheets("Paramètres").Range("BuildingValue").Value
    
    For i = 0 To yearCount - 1
        buildingValuesTmp(i) = initialValue * (1 + realestateIndexes(i)) ^ (i)
    Next
    
    buildingValuesByYear = buildingValuesTmp
End Function

Function cumulatedCashflowsByYear(yCount As Integer) As Double()
    Dim cumulatedCashflowsTmp() As Double
    ReDim Preserve cumulatedCashflowsTmp(0 To yCount)
    
    For i = 0 To yearCount - 1
        If i = 0 Then
            cumulatedCashflowsTmp(i) = cashflows(i)
        Else
            cumulatedCashflowsTmp(i) = cumulatedCashflowsTmp(i - 1) + cashflows(i)
        End If
    Next
    
    cumulatedCashflowsByYear = cumulatedCashflowsTmp
End Function

Sub GenerateClassic()

    ' === Configuration ===
    Dim gracePeriodMonths As Integer
    gracePeriodMonths = Worksheets("Paramètres").Range("EmptyRentalMonthCount").Value

    ' === Setup ===
    Dim sName As String: sName = "Amortissement classique"
    Dim headerRowIndex As Integer: headerRowIndex = 8

    Sheets(sName).Range("A15:G3000").ClearContents

    Dim loan As Double, loanAnnualInterest As Double, loanYearDuration As Integer
    loan = Sheets("Paramètres").Range("AmountBorrowed").Value
    loanAnnualInterest = Sheets("Paramètres").Range("CreditRate").Value
    loanYearDuration = Sheets("Paramètres").Range("CreditPeriod").Value

    Dim loanMonthInterest As Double, loanMonthDuration As Integer
    loanMonthInterest = ((1 + loanAnnualInterest) ^ (1 / 12)) - 1
    loanMonthDuration = loanYearDuration * 12

    Dim loanMonthCharge As Double
    loanMonthCharge = loan * (loanMonthInterest / (1 - (1 + loanMonthInterest) ^ (-loanMonthDuration)))
    
    ' Set monthly charge
    loanClassicMonthlyCharge = loanMonthCharge

    ' === Arrays ===
    ReDim Preserve loanClassicRefunds(0 To loanYearDuration)
    ReDim Preserve loanClassicInterests(0 To loanYearDuration)
    ReDim Preserve remainingClassicRefunds(0 To loanYearDuration)

    Dim refundPlan() As Double, interestPlan() As Double
    ReDim refundPlan(1 To loanMonthDuration)
    ReDim interestPlan(1 To loanMonthDuration)

    ' === Variables ===
    Dim i As Integer, annualIndex As Integer
    Dim iRefund As Double, iInterest As Double, iCharge As Double
    Dim iDate As Date
    Dim totalRefund As Double, totalInterest As Double
    Dim refundMonthlySum As Double, interestsMonthlySum As Double
    Dim remainingCapital As Double: remainingCapital = loan

    ' === First pass: simulate full amortization plan ===
    For i = 1 To loanMonthDuration
        iInterest = remainingCapital * loanMonthInterest
        iRefund = loanMonthCharge - iInterest

        refundPlan(i) = iRefund
        interestPlan(i) = iInterest

        remainingCapital = remainingCapital - iRefund
    Next i

    ' === Compute total deferred capital during grace ===
    Dim totalDeferredCapital As Double
    totalDeferredCapital = 0
    For i = 1 To gracePeriodMonths
        totalDeferredCapital = totalDeferredCapital + refundPlan(i)
    Next i

    Dim postGraceMonths As Integer
    postGraceMonths = loanMonthDuration - gracePeriodMonths

    Dim graceCapitalSpread As Double
    If postGraceMonths > 0 Then
        graceCapitalSpread = totalDeferredCapital / postGraceMonths
    Else
        graceCapitalSpread = 0
    End If

    ' === Final pass: build output ===
    totalRefund = 0
    totalInterest = 0
    refundMonthlySum = 0
    interestsMonthlySum = 0
    remainingCapital = loan

    For i = 1 To loanMonthDuration
        Sheets(sName).Cells(headerRowIndex + i, 1).Value = i
        iDate = DateAdd("m", i, Date)
        Sheets(sName).Cells(headerRowIndex + i, 2).Value = DateSerial(Year(iDate), Month(iDate), 0)

        If i <= gracePeriodMonths Then
            iRefund = 0
            iInterest = interestPlan(i)
            iCharge = iInterest ' only interest
        Else
            iRefund = refundPlan(i) + graceCapitalSpread
            iInterest = interestPlan(i)
            iCharge = iRefund + iInterest
        End If

        totalRefund = totalRefund + iRefund
        totalInterest = totalInterest + iInterest
        refundMonthlySum = refundMonthlySum + iRefund
        interestsMonthlySum = interestsMonthlySum + iInterest

        Sheets(sName).Cells(headerRowIndex + i, 3).Value = iCharge
        Sheets(sName).Cells(headerRowIndex + i, 4).Value = iRefund
        Sheets(sName).Cells(headerRowIndex + i, 5).Value = iInterest
        Sheets(sName).Cells(headerRowIndex + i, 6).Value = loan - totalRefund
        Sheets(sName).Cells(headerRowIndex + i, 7).Value = totalInterest

        ' Optional: format euros (adjust column letters as needed)
        ' Sheets(sName).Cells(headerRowIndex + i, 3).NumberFormat = "#,##0.00 €"
        ' Sheets(sName).Cells(headerRowIndex + i, 4).NumberFormat = "#,##0.00 €"
        ' Sheets(sName).Cells(headerRowIndex + i, 5).NumberFormat = "#,##0.00 €"
        ' Sheets(sName).Cells(headerRowIndex + i, 6).NumberFormat = "#,##0.00 €"
        ' Sheets(sName).Cells(headerRowIndex + i, 7).NumberFormat = "#,##0.00 €"

        If i Mod 12 = 0 Then
            annualIndex = Int(i / 12)
            loanClassicRefunds(annualIndex - 1) = refundMonthlySum
            If annualIndex - 1 = 0 Then
                remainingClassicRefunds(annualIndex - 1) = loan - refundMonthlySum
            Else
                remainingClassicRefunds(annualIndex - 1) = remainingClassicRefunds(annualIndex - 1 - 1) - refundMonthlySum
            End If
            loanClassicInterests(annualIndex - 1) = interestsMonthlySum
            refundMonthlySum = 0
            interestsMonthlySum = 0
        End If
    Next i

    Sheets(sName).Range("TotalInterestClassic").Value = totalInterest

End Sub

Sub GenerateBullet()

    ' Get variables
    sName = "Amortissement bullet"
    headerRowIndex = 8
    yearCount = Sheets("Paramètres").Range("CreditPeriod")
    
    Sheets(sName).Range("A15:G3000").ClearContents
    
    ' Compute
    loan = Sheets("Paramètres").Range("AmountBorrowed").Value
    loanAnnualInterest = Sheets("Paramètres").Range("CreditRate").Value
    loanYearDuration = Sheets("Paramètres").Range("CreditPeriod").Value
    
    loanMonthInterest = ((1 + loanAnnualInterest) ^ (1 / 12)) - 1
    loanMonthDuration = loanYearDuration * 12
    
    loanMonthCharge = loan * loanMonthInterest
    
    ' Set monthly charge
    loanBulletMonthlyCharge = loanMonthCharge
    
    ReDim Preserve loanBulletRefunds(0 To loanYearDuration)
    ReDim Preserve loanBulletInterests(0 To loanYearDuration)
    ReDim Preserve remainingBulletRefunds(0 To loanYearDuration)
    
    totalRefund = 0
    totalInterest = 0
    
    ' Fill term number
    refundMonthlySum = 0
    interestsMonthlySum = 0
    For i = 1 To loanYearDuration * 12
        ' Loan monthly charge number
        Sheets(sName).Cells(headerRowIndex + i, 1) = i
        
        ' Loan monthly charge deadline
        iDate = DateAdd("m", i, Date)
        Sheets(sName).Cells(headerRowIndex + i, 2) = DateSerial(Year(iDate), Month(iDate), 0)
        
        ' Loan monthly charge
        Sheets(sName).Cells(headerRowIndex + i, 3).Value = loanMonthCharge
        
        ' Loan monthly charge refund
        iRefund = 0
        totalRefund = totalRefund + iRefund
        Sheets(sName).Cells(headerRowIndex + i, 4).Value = iRefund
        refundMonthlySum = refundMonthlySum + iRefund
        
        ' Loan monthly charge refund
        iInterest = loanMonthCharge - iRefund
        totalInterest = totalInterest + iInterest
        Sheets(sName).Cells(headerRowIndex + i, 5).Value = iInterest
        interestsMonthlySum = interestsMonthlySum + iInterest
        
        If i Mod 12 = 0 Then
            annualIndex = Int(i / 12)
            loanBulletRefunds(annualIndex - 1) = refundMonthlySum
            If annualIndex - 1 = 0 Then
                remainingBulletRefunds(annualIndex - 1) = loan - refundMonthlySum
            Else
                remainingBulletRefunds(annualIndex - 1) = remainingBulletRefunds(annualIndex - 1 - 1) - refundMonthlySum
            End If
            loanBulletInterests(annualIndex - 1) = interestsMonthlySum
            refundMonthlySum = 0
            interestsMonthlySum = 0
        End If
        
        ' Loan monthly charge remaining
        iRemaining = loan - totalRefund
        Sheets(sName).Cells(headerRowIndex + i, 6).Value = iRemaining

        ' Loan monthly total interest
        Sheets(sName).Cells(headerRowIndex + i, 7).Value = totalInterest
        
    Next
    
    Sheets(sName).Range("TotalInterestBullet").Value = totalInterest

End Sub

Sub ResetInflations()
    sName = "Inflations"
    yearCount = Sheets("Paramètres").Range("CreditPeriod")
    DefaultValue = Sheets("Paramètres").Range("InflationFactor")

    For i = yearCount + 1 To 500
        Sheets(sName).Cells(i, 1).ClearContents
    Next
    
    For i = 1 To yearCount
        Sheets(sName).Cells(i, 1).Value = DefaultValue
    Next
End Sub

Sub ResetHealthIndexes()
    sName = "Inflations"
    yearCount = Sheets("Paramètres").Range("CreditPeriod")
    DefaultValue = Sheets("Paramètres").Range("HealthIndex")
    
    For i = yearCount + 1 To 500
        Sheets(sName).Cells(i, 2).ClearContents
    Next

    For i = 1 To yearCount
        Sheets(sName).Cells(i, 2).Value = DefaultValue
    Next
End Sub

Sub ResetRealEstateInflations()
    sName = "Inflations"
    yearCount = Sheets("Paramètres").Range("CreditPeriod")
    DefaultValue = Sheets("Paramètres").Range("RealEstateInflation")

    For i = yearCount + 1 To 500
        Sheets(sName).Cells(i, 3).ClearContents
    Next

    For i = 1 To yearCount
        Sheets(sName).Cells(i, 3).Value = DefaultValue
    Next
End Sub

Sub FillInflations()
    sName = "Inflations"
    yearCount = Sheets("Paramètres").Range("CreditPeriod")

    ' Inflation
    defaultInflationValue = Sheets("Paramètres").Range("InflationFactor")
    ReDim Preserve inflationFactors(0 To yearCount)

    For i = yearCount + 1 To 500
        Sheets(sName).Cells(i, 1).ClearContents
    Next

    For i = 1 To yearCount
        Value = Sheets(sName).Cells(i, 1).Value
        
        If Value = "" Then
            Sheets(sName).Cells(i, 1).Value = defaultInflationValue
        End If

        inflationFactors(i - 1) = Sheets(sName).Cells(i, 1).Value
    Next

    ' Health index
    defaultHealthIndexValue = Sheets("Paramètres").Range("HealthIndex")
    ReDim Preserve healthIndexes(0 To yearCount)

    For i = yearCount + 1 To 500
        Sheets(sName).Cells(i, 2).ClearContents
    Next

    For i = 1 To yearCount
        Value = Sheets(sName).Cells(i, 2).Value
        
        If Value = "" Then
            Sheets(sName).Cells(i, 2).Value = defaultHealthIndexValue
        End If

        healthIndexes(i - 1) = Sheets(sName).Cells(i, 2).Value
    Next

    ' Realestate index
    defaultRealestateIndexValue = Sheets("Paramètres").Range("RealEstateInflation")
    ReDim Preserve realestateIndexes(0 To yearCount)

    For i = yearCount + 1 To 500
        Sheets(sName).Cells(i, 3).ClearContents
    Next

    For i = 1 To yearCount
        Value = Sheets(sName).Cells(i, 3).Value
        
        If Value = "" Then
            Sheets(sName).Cells(i, 3).Value = defaultRealestateIndexValue
        End If

        realestateIndexes(i - 1) = Sheets(sName).Cells(i, 3).Value
    Next

End Sub

Sub GeneratePlan()
    sPlanName = "Plan financier"
    Sheets(sPlanName).Range("C3:AZ50").ClearContents
    
    yearCount = Sheets("Paramètres").Range("CreditPeriod").Value
    loanType = Sheets("Paramètres").Range("TypeOfCredit").Value

    ' Reset month charge
    Sheets("Paramètres").Range("MonthlyPayment").Value = 0
 
    GenerateClassic
    GenerateBullet
    
    FillInflations
    
    ' Init Cell offset positions
    headerRowIndex = 3
    headerColumnOffset = 3
    firstDataRow = 4
    firstDataColumn = 3
    
    maintenanceRowIndex = firstDataRow + 2
    maintenanceColumnOffset = firstDataColumn
    
    managementRowIndex = firstDataRow + 3
    managementColumnOffset = firstDataColumn
    
    fireInsuranceRowIndex = firstDataRow + 4
    fireInsuranceColumnOffset = firstDataColumn

    deathInsuranceRowIndex = firstDataRow + 5
    deathInsuranceColumnOffset = firstDataColumn
    
    interestsRowIndex = firstDataRow + 6
    interestsColumnOffset = firstDataColumn
    
    refundsRowIndex = firstDataRow + 7
    refundsColumnOffset = firstDataColumn
    
    withholdingsRowIndex = firstDataRow + 9
    withholdingsColumnOffset = firstDataColumn
    
    withholdingIPPsRowIndex = firstDataRow + 10
    withholdingIPPsColumnOffset = firstDataColumn
    
    interestsRowIndex2 = firstDataRow + 11
    interestsColumnOffset2 = firstDataColumn
    
    taxesRowIndex = firstDataRow + 12
    taxesColumnOffset = firstDataColumn
    
    taxBasesRowIndex = firstDataRow + 13
    taxBasesColumnOffset = firstDataColumn
    
    totalOutcomesRowIndex = firstDataRow + 14
    totalOutcomesColumnOffset = firstDataColumn
    
    rentRowIndex = 20
    rentColumnOffset = firstDataColumn
    
    incomeMiscellaneousRowIndex = 21
    incomeMiscellaneousColumnOffset = firstDataColumn
    
    totalIncomesRowIndex = 22
    totalIncomesColumnOffset = firstDataColumn
    
    cashflowRowIndex = 23
    cashflowColumnOffset = firstDataColumn
    
    buildingValuesRowIndex = 25
    buildingValuesColumnOffset = firstDataColumn
    
    cumulatedCashValuesRowIndex = 26
    cumulatedCashVauesColumnOffset = firstDataColumn
    
    remainingRefundValuesRowIndex = 27
    remainingRefundValuesColumnOffset = firstDataColumn
    
    remainingBalanceValuesRowIndex = 28
    remainingBalanceValuesColumnOffset = firstDataColumn
    
    initialContributionValuesRowIndex = 29
    initialContributionValuesColumnOffset = firstDataColumn
    
    netBalanceValuesRowIndex = 30
    netBalanceValuesColumnOffset = firstDataColumn
    
    yieldValuesRowIndex = 31
    yieldValuesColumnOffset = firstDataColumn
    
    basicYieldValuesRowIndex = 32
    basicYieldValuesColumnOffset = firstDataColumn
    
    ' Computation
    ReDim Preserve rents(0 To yearCount)
    rents = rentByYear(yearCount)
    
    ReDim Preserve maintenances(0 To yearCount)
    maintenances = maintenanceByYear(yearCount)
    
    ReDim Preserve managements(0 To yearCount)
    managements = managementByYear(yearCount)
    
    ReDim Preserve rentalLosses(0 To yearCount)
    rentalLosses = rentalLossByYear(yearCount)
    
    ReDim Preserve rentalCosts(0 To yearCount)
    rentalCosts = rentalCostByYear(yearCount)
    
    ReDim Preserve fireInsurances(0 To yearCount)
    fireInsurances = fireInsuranceByYear(yearCount)
    
    ReDim Preserve deathInsurances(0 To yearCount)
    deathInsurances = deathInsuranceByYear(yearCount)
    
    ReDim Preserve withholdings(0 To yearCount)
    withholdings = withholdingsByYear(yearCount)
    
    ReDim Preserve withholdingIPPs(0 To yearCount)
    withholdingIPPs = withholdingsIPPByYear(yearCount)
    
    ReDim Preserve taxes(0 To yearCount)
    taxes = taxesByYear(yearCount)
    
    ReDim Preserve taxBases(0 To yearCount)
    taxBases = taxBasesByYear(yearCount)
    
    ReDim Preserve incomeMiscellaneous(0 To yearCount)
    incomeMiscellaneous = incomeMiscellaneousByYear(yearCount)
    
    ReDim Preserve buildingValues(0 To yearCount)
    buildingValues = buildingValuesByYear(yearCount)
    
    ' Fill financial plan
    
    ' Fill monthly charge
    If loanType = "Classique" Then
        Sheets("Paramètres").Range("MonthlyPayment").Value = loanClassicMonthlyCharge
    Else
        Sheets("Paramètres").Range("MonthlyPayment").Value = loanBulletMonthlyCharge
    End If
    
    ' Fill headers
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(headerRowIndex, i + headerColumnOffset) = i + 1
    Next
    
    ' Fill maintenance
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(maintenanceRowIndex, i + maintenanceColumnOffset) = maintenances(i)
    Next
    
    ' Fill management
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(managementRowIndex, i + managementColumnOffset) = managements(i) + rentalCosts(i)
    Next
    
    ' Fill fire insurance
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(fireInsuranceRowIndex, i + fireInsuranceColumnOffset) = fireInsurances(i)
    Next
    
    ' Fill death insurance
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(deathInsuranceRowIndex, i + deathInsuranceColumnOffset) = deathInsurances(i)
    Next
    
    ' Fill rents
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(rentRowIndex, i + rentColumnOffset) = rents(i) - rentalLosses(i)
    Next
    
    ' Fill interets
    If loanType = "Classique" Then
        loanInterests = loanClassicInterests
    Else
         loanInterests = loanBulletInterests
    End If
    
    If loanType = "Classique" Then
        loanRefunds = loanClassicRefunds
    Else
         loanRefunds = loanBulletRefunds
    End If
    
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(interestsRowIndex, i + interestsColumnOffset) = loanInterests(i)
        Sheets("Plan financier").Cells(interestsRowIndex2, i + interestsColumnOffset2) = loanInterests(i)
    Next
    
    ' Fill refunds
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(refundsRowIndex, i + refundsColumnOffset) = loanRefunds(i)
    Next
    
    ' Fill withholdings
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(withholdingsRowIndex, i + withholdingsColumnOffset) = withholdings(i)
    Next
    
     ' Fill withholding IPPs
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(withholdingIPPsRowIndex, i + withholdingIPPsColumnOffset) = withholdingIPPs(i)
    Next
    
    ' Fill taxes
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(taxesRowIndex, i + taxesColumnOffset) = taxes(i)
    Next
    
    ' Fill tax bases
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(taxBasesRowIndex, i + taxBasesColumnOffset) = taxBases(i)
    Next
    
    ' Fill outcomes
    ReDim Preserve outcomes(0 To yearCount)
    For i = 0 To yearCount - 1
        outcomes(i) = maintenances(i) + managements(i) + rentalCosts(i) + fireInsurances(i) + deathInsurances(i) + loanRefunds(i) + loanInterests(i) + withholdings(i)
        Sheets("Plan financier").Cells(totalOutcomesRowIndex, i + totalOutcomesColumnOffset) = outcomes(i)
    Next
    
    ' Fill incomes
    ReDim Preserve incomes(0 To yearCount)
    For i = 0 To yearCount - 1
        incomes(i) = rents(i) - rentalLosses(i)
        Sheets("Plan financier").Cells(totalIncomesRowIndex, i + totalIncomesColumnOffset) = incomes(i)
        Sheets("Plan financier").Cells(incomeMiscellaneousRowIndex, i + incomeMiscellaneousColumnOffset) = incomeMiscellaneous(i)
    Next
    
    ' Fill cashflow
    ReDim Preserve cashflows(0 To yearCount)
    For i = 0 To yearCount - 1
        cashflows(i) = incomes(i) - outcomes(i)
        Sheets("Plan financier").Cells(cashflowRowIndex, i + cashflowColumnOffset) = cashflows(i)
    Next
    
     ' Fill cashflow
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(buildingValuesRowIndex, i + buildingValuesColumnOffset) = buildingValues(i)
    Next
    
     ' Fill cumulated cash
    ReDim Preserve cumulatedCashflows(0 To yearCount)
    cumulatedCashflows = cumulatedCashflowsByYear(yearCount)
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(cumulatedCashValuesRowIndex, i + cumulatedCashVauesColumnOffset) = cumulatedCashflows(i)
    Next
    
    ' Fill remaining refunds
    ReDim Preserve remainingRefunds(0 To yearCount)
    
    For i = 0 To yearCount - 1
        If loanType = "Classique" Then
            remainingRefunds(i) = -1 * remainingClassicRefunds(i)
        Else
            remainingRefunds(i) = -1 * remainingBulletRefunds(i)
        End If
    
        Sheets("Plan financier").Cells(remainingRefundValuesRowIndex, i + remainingRefundValuesColumnOffset) = remainingRefunds(i)
    Next
    
    ' Fill remaining balances
    ReDim Preserve remainingBalances(0 To yearCount)
    For i = 0 To yearCount - 1
        remainingBalances(i) = buildingValues(i) + cumulatedCashflows(i) + remainingRefunds(i)
        Sheets("Plan financier").Cells(remainingBalanceValuesRowIndex, i + remainingBalanceValuesColumnOffset) = remainingBalances(i)
    Next
    
    ' Fill initial contribution
    ReDim Preserve initialContributions(0 To yearCount)
    initialContribution = Sheets("Paramètres").Range("PersonalContribution").Value
    For i = 0 To yearCount - 1
        initialContributions(i) = -1 * initialContribution
        Sheets("Plan financier").Cells(initialContributionValuesRowIndex, i + initialContributionValuesColumnOffset) = initialContributions(i)
    Next
    
     ' Fill net balances
    ReDim Preserve netBalances(0 To yearCount)
    For i = 0 To yearCount - 1
        netBalances(i) = remainingBalances(i) + initialContributions(i)
        Sheets("Plan financier").Cells(netBalanceValuesRowIndex, i + netBalanceValuesColumnOffset) = netBalances(i)
    Next
    
    ' Fill yields
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(yieldValuesRowIndex, i + yieldValuesColumnOffset) = Abs((remainingBalances(i) / initialContributions(i))) ^ (1 / (i + 1)) - 1
    Next
    
    ' Fill basic yields
    For i = 0 To yearCount - 1
        Sheets("Plan financier").Cells(basicYieldValuesRowIndex, i + basicYieldValuesColumnOffset) = Abs(netBalances(i) / initialContributions(i))
    Next
End Sub